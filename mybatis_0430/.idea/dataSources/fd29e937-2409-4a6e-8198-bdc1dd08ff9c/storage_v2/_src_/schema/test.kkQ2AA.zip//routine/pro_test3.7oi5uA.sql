CREATE PROCEDURE pro_test3()
  begin
   declare num int;
	 select count(*) from employee_basic;
	 select concat('emp表中的记录为:',num);
end;

