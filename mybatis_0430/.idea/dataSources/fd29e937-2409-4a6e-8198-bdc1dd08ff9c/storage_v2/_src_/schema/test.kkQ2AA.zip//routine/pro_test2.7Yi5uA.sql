CREATE PROCEDURE pro_test2()
  begin
 declare num int default 0;
 set num=num+10;
 select num;
end;

