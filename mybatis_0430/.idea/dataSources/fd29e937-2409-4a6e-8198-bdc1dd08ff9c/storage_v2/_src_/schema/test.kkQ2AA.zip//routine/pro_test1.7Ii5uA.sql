CREATE PROCEDURE pro_test1()
  begin
 declare num int default 10;
 select concat('num的值为:',num);
end;

